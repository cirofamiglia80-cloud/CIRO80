import React, {useState} from "react";
import {SafeAreaView,View,Text,StyleSheet,TouchableOpacity,ScrollView,Image,Linking,StatusBar,Alert} from "react-native";

const VITASTRONG_URL = "INSERISCI_QUI_IL_LINK_VITASTRONG_CON_CODICE";

export default function App(){
  const [page,setPage]=useState("home");
  const openShop=async()=>VITASTRONG_URL.startsWith("http")
    ? Linking.openURL(VITASTRONG_URL)
    : Alert.alert("Vita Strong","Inserire qui il link Vita Strong con il codice CIRO80.");

  const Header=()=>(
    <View style={s.header}>
      <Image source={require("./assets/logo.jpeg")} style={s.headerLogo}/>
      <View style={{flex:1}}>
        <Text style={s.brand}>CIA GUAGLIÙ</Text>
        <Text style={s.sub}>CIRODANTO<Text style={{color:"#ff1018"}}>80</Text></Text>
      </View>
    </View>
  );

  const Btn=({title,onPress})=>(
    <TouchableOpacity style={s.btn} onPress={onPress} activeOpacity={.8}>
      <Text style={s.btnText}>{title}</Text><Text style={s.arrow}>›</Text>
    </TouchableOpacity>
  );

  const Card=({title,text,icon,onPress,button})=>(
    <View style={s.card}>
      <Text style={s.icon}>{icon}</Text><Text style={s.cardTitle}>{title}</Text>
      <Text style={s.cardText}>{text}</Text><Btn title={button} onPress={onPress}/>
    </View>
  );

  const Home=()=>(
    <ScrollView contentContainerStyle={s.content}>
      <View style={s.hero}>
        <Image source={require("./assets/logo.jpeg")} style={s.heroLogo}/>
        <View style={{flex:1,paddingLeft:12}}>
          <Text style={s.heroTitle}>CIA GUAGLIÙ</Text>
          <Text style={s.heroSub}>La tua forza, ogni giorno.</Text>
        </View>
      </View>

      <View style={s.grid}>
        <Card title="VITA STRONG" text="Accedi al sito con il tuo codice personale." icon="⚡" button="VAI AL SITO" onPress={openShop}/>
        <Card title="OFFERTE DELLA SETTIMANA" text="Prodotti e promozioni aggiornati da Ciro." icon="%" button="SCOPRI LE OFFERTE" onPress={()=>setPage("offers")}/>
        <Card title="LE RICETTE DI CIRO" text="Foto, ingredienti e preparazione delle ricette." icon="♨" button="SCOPRI LE RICETTE" onPress={()=>setPage("recipes")}/>
        <Card title="COMMUNITY" text="Uno spazio per restare in contatto." icon="●" button="ENTRA NEL GRUPPO" onPress={()=>Alert.alert("Community","Sezione pronta per il collegamento al gruppo scelto.")}/>
        <View style={s.discount}>
          <Text style={s.discountSmall}>CODICE SCONTO</Text>
          <Text style={s.discountCode}>CIRO80</Text>
          <Text style={s.discountText}>Usalo sul sito Vita Strong.</Text>
          <Btn title="ATTIVA IL CODICE" onPress={openShop}/>
        </View>
      </View>

      <View style={s.banner}>
        <Text style={s.bannerTitle}>INSIEME SI VA PIÙ LONTANO</Text>
        <Text style={s.bannerSub}>DISCIPLINA • ALIMENTAZIONE • RISULTATI</Text>
      </View>
    </ScrollView>
  );

  const Offers=()=>(
    <ScrollView contentContainerStyle={s.content}>
      <Text style={s.pageTitle}>OFFERTE DELLA SETTIMANA</Text>
      <Text style={s.pageIntro}>Questa sezione sarà aggiornata con i prodotti e le offerte Vita Strong.</Text>
      {[1,2].map(i=><View style={s.item} key={i}>
        <Text style={s.badge}>{i===1?"OFFERTA":"NEW"}</Text>
        <Text style={s.itemTitle}>{i===1?"Prodotto in evidenza":"Nuova proposta"}</Text>
        <Text style={s.itemText}>Qui inseriremo foto, prezzo e descrizione dell'offerta.</Text>
        <Btn title="VAI A VITA STRONG" onPress={openShop}/>
      </View>)}
    </ScrollView>
  );

  const Recipes=()=>(
    <ScrollView contentContainerStyle={s.content}>
      <Text style={s.pageTitle}>LE RICETTE DI CIRO</Text>
      <Text style={s.pageIntro}>Ricette fotografiche con ingredienti, procedimento e prodotti Vita Strong.</Text>
      {[1,2].map(i=><View style={s.item} key={i}>
        <View style={s.photo}><Text style={s.photoText}>FOTO RICETTA</Text></View>
        <Text style={s.itemTitle}>Ricetta di Ciro #{i}</Text>
        <Text style={s.itemText}>Ingredienti e preparazione verranno inseriti qui.</Text>
      </View>)}
    </ScrollView>
  );

  return <SafeAreaView style={s.safe}>
    <StatusBar barStyle="light-content" backgroundColor="#000"/>
    <Header/>
    {page==="home"&&<Home/>}{page==="offers"&&<Offers/>}{page==="recipes"&&<Recipes/>}
    <View style={s.nav}>
      <Nav label="Home" icon="⌂" active={page==="home"} onPress={()=>setPage("home")}/>
      <Nav label="Offerte" icon="%" active={page==="offers"} onPress={()=>setPage("offers")}/>
      <Nav label="Ricette" icon="♨" active={page==="recipes"} onPress={()=>setPage("recipes")}/>
      <Nav label="Vita Strong" icon="↗" onPress={openShop}/>
    </View>
  </SafeAreaView>
}
function Nav({label,icon,active,onPress}){return <TouchableOpacity style={s.navItem} onPress={onPress}><Text style={[s.navIcon,active&&s.active]}>{icon}</Text><Text style={[s.navLabel,active&&s.active]}>{label}</Text></TouchableOpacity>}

const s=StyleSheet.create({
 safe:{flex:1,backgroundColor:"#000"},header:{height:82,backgroundColor:"#050505",borderBottomWidth:1,borderBottomColor:"#ff1018",flexDirection:"row",alignItems:"center",paddingHorizontal:14},
 headerLogo:{width:58,height:58,borderRadius:14,marginRight:12},brand:{color:"#fff",fontSize:22,fontWeight:"900"},sub:{color:"#fff",fontSize:12,fontWeight:"800"},
 content:{padding:16,paddingBottom:110},hero:{backgroundColor:"#090909",borderWidth:1,borderColor:"#ff1018",borderRadius:18,padding:14,flexDirection:"row",alignItems:"center",marginBottom:16},
 heroLogo:{width:112,height:112,borderRadius:18},heroTitle:{color:"#fff",fontSize:29,fontWeight:"900"},heroSub:{color:"#fff",fontSize:16,marginTop:8,fontStyle:"italic"},
 grid:{gap:14},card:{backgroundColor:"#080808",borderWidth:1.5,borderColor:"#ff1018",borderRadius:18,padding:16},icon:{color:"#ff1018",fontSize:28,fontWeight:"900"},
 cardTitle:{color:"#fff",fontSize:20,fontWeight:"900",marginTop:5},cardText:{color:"#ddd",fontSize:14,lineHeight:20,marginTop:6,marginBottom:14},
 btn:{backgroundColor:"#ff1018",borderRadius:28,minHeight:46,paddingHorizontal:16,flexDirection:"row",alignItems:"center",justifyContent:"space-between"},btnText:{color:"#fff",fontSize:14,fontWeight:"900"},arrow:{color:"#fff",fontSize:28},
 discount:{backgroundColor:"#080808",borderWidth:2,borderColor:"#ff1018",borderRadius:18,padding:18},discountSmall:{color:"#fff",fontSize:16,fontWeight:"900"},discountCode:{color:"#ff1018",fontSize:42,fontWeight:"900",letterSpacing:2},discountText:{color:"#ddd",marginBottom:14},
 banner:{marginTop:16,padding:18,borderWidth:1,borderColor:"#ff1018",borderRadius:18,backgroundColor:"#080808"},bannerTitle:{color:"#fff",fontSize:22,fontWeight:"900"},bannerSub:{color:"#ff1018",fontSize:12,fontWeight:"900",marginTop:8},
 pageTitle:{color:"#fff",fontSize:28,fontWeight:"900",marginBottom:8},pageIntro:{color:"#ccc",fontSize:15,lineHeight:21,marginBottom:16},item:{backgroundColor:"#090909",borderWidth:1.5,borderColor:"#ff1018",borderRadius:18,padding:16,marginBottom:14},
 badge:{color:"#ff1018",fontWeight:"900"},itemTitle:{color:"#fff",fontSize:21,fontWeight:"900",marginTop:7},itemText:{color:"#ddd",fontSize:14,lineHeight:20,marginVertical:12},photo:{height:180,borderRadius:12,borderWidth:1,borderColor:"#333",alignItems:"center",justifyContent:"center",backgroundColor:"#111"},photoText:{color:"#666",fontWeight:"900"},
 nav:{position:"absolute",bottom:0,left:0,right:0,height:78,backgroundColor:"#050505",borderTopWidth:1,borderTopColor:"#333",flexDirection:"row",justifyContent:"space-around"},navItem:{alignItems:"center",justifyContent:"center",flex:1},navIcon:{color:"#fff",fontSize:24},navLabel:{color:"#fff",fontSize:11,marginTop:2},active:{color:"#ff1018"}
});
