# CIA GUAGLIÙ — CIRO80

Progetto Expo/React Native iniziale, creato da zero.

## Contenuti
- Home in stile nero/rosso/neon
- Vita Strong
- Codice sconto CIRO80
- Offerte della settimana
- Ricette di Ciro
- Community (predisposta)

## Prima della build
Aprire `App.js` e sostituire:
`INSERISCI_QUI_IL_LINK_VITASTRONG_CON_CODICE`
con il link Vita Strong corretto.

Il progetto è predisposto per essere caricato su GitHub e poi usato con Expo/EAS.
