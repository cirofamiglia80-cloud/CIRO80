# Cià Guagliù — App v2
Progetto Expo/React Native con Home, coupon CIRO80, ricette con ricerca/categorie/dettaglio nutrizionale, Offerte e Profilo.
Il link acquisto usa https://vitastrong.it/?coupon=CIRO80.
Per pubblicare su App Store/Google Play servono build EAS e gli account sviluppatore.

## Build
Il progetto include `eas.json` per build development, preview APK e production Android/iOS. Vedi `BUILD_GUIDE.md`.
