# Cià Guagliù — build Android + iPhone

Il progetto è configurato per EAS Build.

## 1. Login Expo
```bash
eas login
eas whoami
```

## 2. Build di prova installabile
### Android APK
```bash
eas build --platform android --profile preview
```

### iPhone
```bash
eas build --platform ios --profile preview
```

Per iOS, la distribuzione interna richiede la gestione dei dispositivi/profili Apple da parte di EAS.

## 3. Build per gli store
```bash
eas build --platform all --profile production
```

Il risultato Android è un AAB per Google Play; il risultato iOS è una build destinata ad App Store Connect/TestFlight.

## 4. Invio agli store
```bash
eas submit --platform android --profile production
eas submit --platform ios --profile production
```

Sono necessari gli account sviluppatore e le credenziali di firma dei rispettivi store. EAS può gestire le credenziali di firma guidando la configurazione.
