# Gestione contenuti — Cià Guagliù

La struttura è pronta per spostare ricette/offerte da dati locali a un database remoto.

## Modello ricetta
- id
- title
- category
- kcal
- protein_g
- carbs_g
- fat_g
- time_min
- ingredients[]
- steps[]
- image_url

## In una versione con pannello admin
Potrai:
1. aggiungere una ricetta;
2. modificare ingredienti e valori nutrizionali;
3. caricare una foto;
4. pubblicare/nascondere la ricetta;
5. creare offerte;
6. aggiornare testi e banner.

Nota: per un'app pubblicata, i dati nutrizionali dovrebbero essere verificati prima della pubblicazione, soprattutto se le ricette vengono presentate come indicazioni per pazienti o persone con esigenze alimentari specifiche.
